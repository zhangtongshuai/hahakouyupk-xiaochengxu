const app = getApp()
const db = wx.cloud.database()
Page({
  data: {
    avatarUrl: '../../images/user-unlogin.png',
    userInfo: {},
    logged: false,
    takeSession: false,
    requestResult: '',
    growthvalue:''
  },
  onLoad: function () {
    if (!wx.cloud) {
      wx.redirectTo({
        url: '../chooseLib/chooseLib',
      })
      return
    }
  },
  onShow: function () {
    var that = this;
    wx.showShareMenu({
      withShareTicket: true,
    })
    var user = wx.getStorageSync('user');
    console.log(user)
    var openid = user.openid;
    db.collection('growup').where({
      _openid: openid,
    }).get({
      success: function (res) {
        console.log(res.data)
        that.setData({
          growthvalue: res.data[0].growthvalue
        })
      }
    })
    // 获取用户信息
    wx.getSetting({
      success: res => {
        console.log(res)
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: re => {
              console.log(re)
              this.setData({
                avatarUrl: re.userInfo.avatarUrl,
                userInfo: re.userInfo
              })
              wx.setStorageSync('userInfo', re.userInfo);
            }
          })
        } else {
          console.log('获取用户信息失败')
          wx.showModal({
            title: '警告',
            content: '尚未进行授权登录,请点击确定跳转到授权页面进行授权',
            showCancel: false,
            success: function (re) {
              if (re.confirm) {
                console.log('用户点击确定')
                wx.navigateTo({
                  url: '../login/login',
                })
              }
            }
          })
        }
      }
    })
  },
  onShareAppMessage: function () {
    var path = '/pages/myinfo/myinfo';
    return {
      title: '英语口语PK',
      desc: '快来和你的小伙伴一起练习口语吧',
      path: path,
      success: function (res) {
        // 转发成功
        console.log(res)
        wx.getSystemInfo({
          success: function (d) {
            console.log(d);
            //判断用户手机是IOS还是Android
            if (d.platform == 'android') {
              wx.getShareInfo({//获取群详细信息
                shareTicket: res.shareTickets,
                success: function (r) {
                  //这里写你分享到群之后要做的事情，比如增加次数什么的
                  var user = wx.getStorageSync('user');
                  var openid = user.openid;
                  db.collection('growup').where({
                    _openid: openid,
                  }).get({
                    success: function (re) {
                      console.log(re.data)
                      if (re.data != '') {
                        var id = re.data[0]._id;
                        var oldgrowth = re.data[0].growthvalue;
                        db.collection('growup').doc(id).update({
                          // data 传入需要局部更新的数据
                          data: {
                            // 表示将 done 字段置为 true
                            growthvalue: oldgrowth + 15,
                          },
                          success: console.log,
                          fail: console.error
                        })
                      }
                    }
                  })
                },
                fail: function (res) {//这个方法就是分享到的是好友，给一个提示
                }
              })
            }
            if (d.platform == 'ios') {//如果用户的设备是IOS
              if (res.shareTickets != undefined) {
                console.log("分享的是群");
                wx.getShareInfo({
                  shareTicket: res.shareTickets,
                  success: function (r) {
                    //分享到群之后你要做的事情
                    var user = wx.getStorageSync('user');
                    var openid = user.openid;
                    db.collection('growup').where({
                      _openid: openid,
                    }).get({
                      success: function (re) {
                        console.log(re.data)
                        if (re.data != '') {
                          var id = re.data[0]._id;
                          var oldgrowth = re.data[0].growthvalue;
                          db.collection('growup').doc(id).update({
                            // data 传入需要局部更新的数据
                            data: {
                              // 表示将 done 字段置为 true
                              growthvalue: oldgrowth + 15,
                            },
                            success: console.log,
                            fail: console.error
                          })
                        }
                      }
                    })
                  }
                })
              } else {//分享到个人要做的事情，我给的是一个提示
                console.log("分享的是个人");
              }
            }
          },
          fail: function (m) {
            console.log(m)
          }
        })
      },
      fail: function (n) {
        // 转发失败
        console.log(n)
      }
    }
  },
  onGetUserInfo: function (e) {
    if (!this.logged && e.detail.userInfo) {
      this.setData({
        logged: true,
        avatarUrl: e.detail.userInfo.avatarUrl,
        userInfo: e.detail.userInfo
      })
    }
  },
})