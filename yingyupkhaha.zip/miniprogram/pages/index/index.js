//index.js
const app = getApp()
const recorderManager = wx.getRecorderManager()
const innerAudioContext = wx.createInnerAudioContext()
const db = wx.cloud.database()
const timestamp = Date.parse(new Date()); 
Page({
  data: {
    appid: 'wx2c331fc1ccb281c2',
    secret: 'f5637bd9ab8d072712274dc65e5af536',
    currentTab: 0,
    chinese:'',
    english:'',
    audioarr:[],
    growtharr:[],
    record_status1:1,
    record_status2:2,
    record_status3:2,
    record_status4:2,
    interim_src:'',
    record_src:'',
    record_fail:'0',
    isPlaying: false,
    PlayingID: '',
    audio:false
  },
  onLoad: function() {
    if (!wx.cloud) {
      wx.redirectTo({
        url: '../chooseLib/chooseLib',
      })
      return
    }
  },
  onShow: function () {
    var that = this;
    wx.showShareMenu({
      withShareTicket: true,
    })
    var num = 'num'
    wx.request({
      url: 'https://vedio.jiudingfanyi.com/api/vocab/detail/' +num, //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res)
      }
    })
    // 获取用户信息
    wx.getSetting({
      success: res => {
        console.log(res)
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: re => {
              console.log(re)
              wx.setStorageSync('userInfo', re.userInfo);
            }
          })
        } else {
          console.log('获取用户信息失败')
          wx.showModal({
            title: '警告',
            content: '尚未进行授权登录,请点击确定跳转到授权页面进行授权',
            showCancel: false,
            success: function (re) {
              if (re.confirm) {
                console.log('用户点击确定')
                wx.navigateTo({
                  url: '../login/login',
                })
              }
            }
          })
        }
        if (res.authSetting['scope.record']) {
          console.log('授权成功')
          that.setData({
            record_fail: 0
          })
        }
      }
    })
    db.collection('english_sentences').get({
      success: function (res) {
        // res.data 包含该记录的数据
        console.log(res.data)
        that.setData({
          chinese: res.data[0].chinese,
          english: res.data[0].english
        })
      }
    })
    var userInfo = wx.getStorageSync('userInfo');
    var user = wx.getStorageSync('user');
    console.log(user)
    var openid = user.openid;
    console.log(user)
    if (!user.openid || user.openid == '') {
      wx.login({
        success: function (res) {
          console.log(res)
          if (res.code) {
            var d = that.data;//这里存储了appid、secret、token串                  
            var l = 'https://api.weixin.qq.com/sns/jscode2session?appid=' + d.appid + '&secret=' + d.secret + '&js_code=' + res.code + '&grant_type=authorization_code';
            wx.request({
              url: l,
              data: {},
              method: 'GET',
              success: function (res) {
                console.log(res)
                var obj = {};
                obj.openid = res.data.openid;
                wx.setStorageSync('user', obj);//存储openid
                db.collection('growup').where({
                  _openid: openid,
                }).get({
                  success: function (res) {
                    console.log(res.data)
                    if (res.data == '') {
                      db.collection('growup').add({
                        // data 字段表示需新增的 JSON 数据
                        data: {
                          // _id: 'todo-identifiant-aleatoire', // 可选自定义 _id，在此处场景下用数据库自动分配的就可以了
                          growthvalue: 0,
                          user_name: userInfo.nickName,
                          user_portrait: userInfo.avatarUrl
                        },
                        success: function (res) {
                          // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
                          console.log(res)
                        },
                        fail: console.error
                      })
                    }
                  }
                })                      
              }
            });
          } else {
            console.log('获取用户登录态失败！' + res.errMsg)
          }
        }
      });
    }
    db.collection('audios').orderBy('audio_lauds', 'desc')
      .get({
        success: function (e) {
          console.log(e)
          var arr = [];
          for (var i = 0; i < e.data.length; i++) {
            var num = i + 1;
            var objct = {
              listnum: num,
              id: e.data[i]._id,
              audio_lauds: e.data[i].audio_lauds,
              audio_listeners: e.data[i].audio_listeners,
              audio_name: e.data[i].audio_name,
              audio_portrait: e.data[i].audio_portrait,
              audio_record: e.data[i].audio_record,
              showAudio: false,
              showLauds: false
            }
            arr.push(objct);
          }
          that.setData({
            audioarr: arr
          })
          console.log(arr)
        }
      })
    db.collection('growup').orderBy('growthvalue', 'desc')
      .get({
        success: function (e) {
          console.log(e)
          var arr = [];
          for (var i = 0; i < e.data.length; i++) {
            var objct = {
              id: i + 1,
              user_portrait: e.data[i].user_portrait,
              user_name: e.data[i].user_name,
              growthvalue: e.data[i].growthvalue
            }
            arr.push(objct);
          }
          that.setData({
            growtharr: arr
          })
        }
      })
  },
  onShareAppMessage: function (e) {
    var path = '/pages/index/index';
    return {
      title: '英语口语PK',
      desc: '快来和你的小伙伴一起练习口语吧',
      path: path,
      success: function (res) {
        // 转发成功
        console.log(res)
        wx.getSystemInfo({
          success: function (d) {
            console.log(d);
            //判断用户手机是IOS还是Android
            if (d.platform == 'android') {
              wx.getShareInfo({//获取群详细信息
                shareTicket: res.shareTickets,
                success: function (r) {
                  //这里写你分享到群之后要做的事情，比如增加次数什么的
                  var user = wx.getStorageSync('user');
                  var openid = user.openid;
                  db.collection('growup').where({
                    _openid: openid,
                  }).get({
                    success: function (re) {
                      console.log(re.data)
                      if (re.data != '') {
                        var id = re.data[0]._id;
                        var oldgrowth = re.data[0].growthvalue;
                        db.collection('growup').doc(id).update({
                          // data 传入需要局部更新的数据
                          data: {
                            // 表示将 done 字段置为 true
                            growthvalue: oldgrowth + 15,
                          },
                          success: console.log,
                          fail: console.error
                        })
                      }
                    }
                  })
                },
                fail: function (res) {//这个方法就是分享到的是好友，给一个提示
                }
              })
            }
            if (d.platform == 'ios') {//如果用户的设备是IOS
              if (res.shareTickets != undefined) {
                console.log("分享的是群");
                wx.getShareInfo({
                  shareTicket: res.shareTickets,
                  success: function (r) {
                    //分享到群之后你要做的事情
                    var user = wx.getStorageSync('user');
                    var openid = user.openid;
                    db.collection('growup').where({
                      _openid: openid,
                    }).get({
                      success: function (re) {
                        console.log(re.data)
                        if (re.data != '') {
                          var id = re.data[0]._id;
                          var oldgrowth = re.data[0].growthvalue;
                          db.collection('growup').doc(id).update({
                            // data 传入需要局部更新的数据
                            data: {
                              // 表示将 done 字段置为 true
                              growthvalue: oldgrowth + 15,
                            },
                            success: console.log,
                            fail: console.error
                          })
                        }
                      }
                    })
                  }
                })
              } else {//分享到个人要做的事情，我给的是一个提示
                console.log("分享的是个人");             
              }
            }
          },
          fail: function (m) {
            console.log(m)
          }
        })
      },
      fail: function (n) {
        // 转发失败
        console.log(n)
      }
    }
  },
  //开始录音
  startRecord:function(e){
    var that = this;
    this.setData({
      record_status1: 2,
      record_status2: 1,
      record_status3: 2,
      record_status4: 2
    })
    const options = {
      duration: 60000,//指定录音的时长，单位 ms
      sampleRate: 16000,//采样率
      numberOfChannels: 1,//录音通道数
      encodeBitRate: 96000,//编码码率
      format: 'mp3',//音频格式，有效值 aac/mp3
      frameSize: 50,//指定帧大小，单位 KB
    }
    //开始录音
    recorderManager.start(options);
    recorderManager.onStart(() => {
      console.log('recorder start')
    });
    //错误回调
    recorderManager.onError((res) => {
      console.log(res);
      that.setData({
        record_status1: 1,
        record_status2: 2,
        record_status3: 2,
        record_status4: 2
      })
      wx.getSetting({
        success: function (re) {
          console.log(re)
          if (re.authSetting['scope.record']){
            console.log('授权成功')
          }else{
            wx.showModal({
              title: '警告',
              content: '尚未进行授权录音,请点击打开设置页按钮到授权页面开启录音授权',
              showCancel: false,
              success: function (re) {
                if (re.confirm) {
                  console.log('用户点击确定')
                  that.setData({
                    record_fail: 1
                  })
                }
              }
            })
          }
        }
      })
    })
  },
  openSetting:function(e){
    wx.openSetting({
      success: function (c) {
        console.log(c)
      }
    })
  },
  stopRecord: function (e) {
    var that = this;
    this.setData({
      record_status1: 2,
      record_status2: 2,
      record_status3: 1,
      record_status4: 2
    })
    recorderManager.stop();
    recorderManager.onStop((res) => {
      this.tempFilePath = res.tempFilePath;
      console.log('停止录音', res.tempFilePath)
      that.setData({
        interim_src: res.tempFilePath
      })
    })
  },
  playRecord:function(e){
    var that = this;
    that.setData({
      record_status1: 2,
      record_status2: 2,
      record_status3: 2,
      record_status4: 1
    })
    innerAudioContext.autoplay = true
    innerAudioContext.src = this.tempFilePath,
    innerAudioContext.play()
    innerAudioContext.onPlay(() => {
      console.log('开始播放')
    })
    innerAudioContext.onEnded(() => {
      console.log('播放结束')
      that.setData({
        record_status1: 2,
        record_status2: 2,
        record_status3: 1,
        record_status4: 2
      })
    })    
  },
  pauseRecord:function(e){
    this.setData({
      record_status1: 2,
      record_status2: 2,
      record_status3: 1,
      record_status4: 2
    })
    innerAudioContext.stop()
    innerAudioContext.onStop(() => {
      console.log('播放停止')
    })
  },
  rerecord:function(e){
    var that = this;
    this.setData({
      record_status1: 2,
      record_status2: 1,
      record_status3: 2,
      record_status4: 2
    })
    const options = {
      duration: 60000,//指定录音的时长，单位 ms
      sampleRate: 16000,//采样率
      numberOfChannels: 1,//录音通道数
      encodeBitRate: 96000,//编码码率
      format: 'mp3',//音频格式，有效值 aac/mp3
      frameSize: 50,//指定帧大小，单位 KB
    }
    //开始录音
    recorderManager.start(options);
    recorderManager.onStart(() => {
      console.log('recorder start')
    });
    //错误回调
    recorderManager.onError((res) => {
      console.log(res);
    })
  },
  releaseBtn:function(e){
    var that = this;
    wx.cloud.uploadFile({
      cloudPath: 'audios/' + timestamp + '.mp3',
      filePath: this.data.interim_src, // 小程序临时文件路径
      success: re => {
        // get resource ID
        console.log(re)
        console.log(re.fileID)
        that.setData({
          record_src: re.fileID
        })
        var userInfo = wx.getStorageSync('userInfo');
        db.collection('audios').add({
          // data 字段表示需新增的 JSON 数据
          data: {
            // _id: 'todo-identifiant-aleatoire', // 可选自定义 _id，在此处场景下用数据库自动分配的就可以了
            audio_lauds: 0,
            audio_listeners: 0,
            audio_name: userInfo.nickName,
            audio_portrait: userInfo.avatarUrl,
            audio_record: re.fileID
          },
          success: function (res) {
            // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
            console.log(res)
            wx.showToast({
              title: '发布成功',
              icon: 'success',
              duration: 1000,
              mask: false,
            });
            that.setData({
              record_status1: 1,
              record_status2: 2,
              record_status3: 2,
              record_status4: 2
            })
            var user = wx.getStorageSync('user');
            var openid = user.openid;
            db.collection('growup').where({
              _openid: openid,
            }).get({
              success: function (d) {
                console.log(d.data)
                if (d.data != '') {
                  var id = d.data[0]._id;
                  var oldgrowth = d.data[0].growthvalue;
                  db.collection('growup').doc(id).update({
                    // data 传入需要局部更新的数据
                    data: {
                      // 表示将 done 字段置为 true
                      growthvalue: oldgrowth + 10,
                    },
                    success: console.log,
                    fail: console.error
                  })
                }
              }
            })
          },
          fail: console.error
        })
      }
    });
    
  },
  //滑动切换
  swiperTab: function (e) {
    var that = this;
    that.setData({
      currentTab: e.detail.current
    });
  },
  //点击切换
  clickTab: function (e) {
    var that = this;
    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },
  playAudio: function(e) {//带滚动条多个音频处理问题
    console.log(e)
    var that = this
    var arr = that.data.audioarr
    var index = e.currentTarget.dataset.index
    var _id = e.currentTarget.id
    for (var i = 0; i < arr.length; i++) {//将所有的音频置为停止状态
      that.setAudioType(i, false)
    }
    that.setAudioType(index, true)//将当前音频置为播放状态
    innerAudioContext.autoplay = true
    innerAudioContext.src = e.currentTarget.dataset.src,
    innerAudioContext.play()
    innerAudioContext.onPlay(() => {
      console.log('开始播放')
      db.collection('audios').where({
        _id: _id,
      }).get({
        success: function (d) {
          console.log(d.data)
          if (d.data != '') {
            var id = d.data[0]._id;
            var oldlisteners = d.data[0].audio_listeners;
            db.collection('audios').doc(id).update({
              // data 传入需要局部更新的数据
              data: {
                // 表示将 done 字段置为 true
                audio_listeners: oldlisteners + 1,
              },
              success: function(w){
                console.log(w)
              },
              fail: function (w) {
                console.log(w)
              }
            })
          }
        }
      })
    })
    // that.data.audio = wx.getBackgroundAudioManager();//初始化音频并播放
    // that.data.audio.src = e.currentTarget.dataset.src
    // that.data.audio.autoplay = true
    // that.data.audio.play();
    //音频自然播放结束
    innerAudioContext.onEnded(() => {
      that.setAudioType(index, false)
      var oldlisteners = arr[index].audio_listeners
      var newlisteners = oldlisteners + 1
      arr[index].audio_listeners = newlisteners
      that.setData({
        audioarr: arr
      })
    })
    // that.data.audio.onEnded(function name(params) {
    //   that.setAudioType(index, false)
    // })
  },
  //停止播放音频
  pauseAudio: function (e) {
    var that = this
    var index = e.currentTarget.dataset.index
    var arr = that.data.audioarr
    // that.data.audio.pause()
    innerAudioContext.stop()
    innerAudioContext.onStop(() => {
      console.log('播放停止')
    })
    that.setAudioType(index, false)
    var oldlisteners = arr[index].audio_listeners
    var newlisteners = oldlisteners + 1
    arr[index].audio_listeners = newlisteners
    that.setData({
      audioarr: arr
    })
  },
  setAudioType: function(index, tag){
    var that = this
    var arrs = that.data.audioarr
    arrs[index].showAudio = tag
    that.setData({
      audioarr: arrs
    })
  },
  laudsAudio: function (e){
    console.log(e)
    var that = this
    var index = e.currentTarget.dataset.index
    var _id = e.currentTarget.id
    that.setLaudsType(index, true)
    db.collection('audios').where({
      _id: _id,
    }).get({
      success: function (d) {
        console.log(d.data)
        if (d.data != '') {
          var id = d.data[0]._id;
          var oldlauds = d.data[0].audio_lauds;
          db.collection('audios').doc(id).update({
            // data 传入需要局部更新的数据
            data: {
              // 表示将 done 字段置为 true
              audio_lauds: oldlauds + 1,
            },
            success: console.log,
            fail: console.error
          })
        }
      }
    })
  },
  setLaudsType: function (index,tag) {
    var that = this
    var arrs = that.data.audioarr
    arrs[index].showLauds = tag
    arrs[index].audio_lauds = arrs[index].audio_lauds+1
    that.setData({
      audioarr: arrs
    })
  },
})
